import React from 'react'

const SectionTwelve = () => {
   return (
      <section id="faq" class="row grey-section">
          <div class=" container ">
            <div class="row">
                <div class="col-md-6"> when can i join?</div>
                <div class="col-md-6 text-center">
                  <h4 class="font-blue">FAQ</h4>
                  <h2>Still Not Sure?</h2>
                </div>
            </div>
          </div>
        </section>
   )
}

export default SectionTwelve
