import React from 'react'

const SectionEleven = () => {
   return (
      <section class="row">
          <div class=" container text-center">
          <h4 class="font-blue">Find out why our users love Rhythmoya</h4>
          <h2 class="section-heading">Don't Just Our World For It</h2>
          </div>
      </section>
   )
}

export default SectionEleven
